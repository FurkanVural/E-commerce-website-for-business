document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("searchForm").addEventListener("submit", function(event) {
      event.preventDefault(); // Formun varsayılan gönderme işlemini engelle
      searchFunction();
    });
  });
  
  function searchFunction() {
    var searchTerm = document.getElementById("searchInput").value;
    if (searchTerm.trim() !== "") {
      // Arama terimini URL'e ekleyerek yönlendirme yap
      window.location.href = "arama.php?search=" + encodeURIComponent(searchTerm);
    } else {
      // Arama terimi boşsa uyarı ver
      alert("Lütfen bir arama terimi girin.");
    }
  }