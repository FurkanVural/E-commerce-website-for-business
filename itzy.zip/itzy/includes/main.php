
</head>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/662569b9a0c6737bd12ec581/1hs129vn2';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->


<body>



  <header class="page-header">
    <!-- topline -->
    <div class="page-header__topline">
      <div class="container clearfix">

        <div class="currency">
          <a class="currency__change" href="customer/my_account.php?my_orders">
          <?php


          if(!isset($_SESSION['customer_email'])){
          echo "Welcome :Guest"; 
          }
          else
          { 
              echo "Welcome : " . $_SESSION['customer_email'] . "";
            }
?>
          </a>
        </div>

        <div class="basket" style=" margin-top: 0px; margin-bottom: 1px;">
    <a href="cart.php" class="btn btn--basket" style="display: flex; align-items: center;">
        <div>
            <i class="icon-basket" style="margin-left: 3px;"></i>
            <span style="margin-left: 5px;"><?php items(); ?> items</span>
        </div>
    </a>
</div>




        
        
        <ul class="login">

<li class="login__item">
<?php
if(!isset($_SESSION['customer_email'])){
  echo '<a href="customer_register.php" class="login__link" style="margin-top: 1px; margin-bottom: 10px;" >Register</a>';
} 
  else
  { 
      echo '<a href="customer/my_account.php?my_orders" class="login__link"   style=" margin-top: 1px;margin-top: 1px; margin-bottom: 10px;" >My Account</a>';
  }   
?>  
</li>


<li class="login__item">
<?php
if(!isset($_SESSION['customer_email'])){ 
  echo '<a href="signin.php" class="login__link" style=" margin-top: 1px; margin-bottom: 10px;" >Sign In</a>';
} 
  else
  { 
      echo '<a href="logout.php" class="login__link"  style="margin-top: 1px; margin-bottom: 10px;" >Log out</a>';
  }   
?>  
  
</li>
</ul>
      
      </div>
    </div>
    <!-- bottomline -->
    <script src="js/script.js"></script>
    <div class="page-header__bottomline">
      <div class="container clearfix">

        <div class="logo">
          <a class="logo__link" href="index.php">
            <img class="logo__img" src="images/logo1.png" alt="Izzy logotype" width="237" height="19">
          </a>
        </div>

        <div class="page-header__bottomline">
        <div class="search-container">
        <form action="search.php" method="GET"> <!-- Arama formunu search.php'ye yönlendirme -->
    <input type="text" name="search" placeholder="Search by Material, Color or Category ..." class="search-input" id="searchInput" required>
    <button type="submit" class="search-button">
      <style>
        .search-button {
          font-size: 14px;
        }
      </style>
   <!-- <img src="images/search.png" alt="Ara İkonu" width=" 3px" height=" 3px"> -->
   Search
    </button>
  </form>
</div>


        <nav class="main-nav">
          <ul class="categories">
            <li class="categories__item">
              <a class="categories__link categories__link--active" href="shop.php">
                <center>
              <img class="logo__img" src="images/shop.png" alt="Izzy logotype" width=" 40" height=" 40">
              <br>Shop
                </center>
              </a>
            </li>
            <li class="categories__item">
              <a class="categories__link" href="about.php">
              <center>
              <img class="logo__img" src="images/about2.png" alt="Izzy logotype" width=" 40" height=" 40">
              <br>About us
                </center>
              </a>
            </li>
            <li class="categories__item">
              <a class="categories__link" href="customer/my_account.php?my_wishlist">
              <center>
              <img class="logo__img" src="images/fav2.png" alt="Izzy logotype" width=" 40" height=" 40">
              <br>Favorites
                </center>
                
              </a>
            </li>
          <li class="categories__item">
              <a class="categories__link" href="customer/my_account.php?my_orders">
              <center>
              <img class="logo__img" src="images/account2.png" alt="Izzy logotype" width=" 40" height=" 40">
              <br>My Account
                </center>
                <i class="icon-down-open-1"></i>
              </a>
              <div class="dropdown dropdown--lookbook">
                <div class="clearfix">
                  <div class="dropdown__half">
                  <div class="dropdown__half">
                    <div class="dropdown__heading"></div>

                    <ul class="dropdown__items">
                      
                      <li class="dropdown__item">
                        <a class="dropdown__link" href="customer/my_account.php?my_orders">My Orders</a>
                      </li>
                      <li class="dropdown__item">
                        <a href="cart.php" class="dropdown__link">View Shopping Cart</a>
                      </li>
                    </ul>
                  </div>
                  
                    <ul class="dropdown__items">
                      <li class="dropdown__item">
                        <a href="customer/my_account.php?edit_account" class="dropdown__link">Edit Your Account</a>
                      </li>
                      <li class="dropdown__item">
                        <a href="customer/my_account.php?change_pass" class="dropdown__link">Change Password</a>
                      </li>
                      <li class="dropdown__item">
                        <a href="contact.php" class="dropdown__link">Contact Us</a>
                      </li>
                      
                    </ul>
                  </div>
                </div>
             

              </div>


              <!--
            </li>
            <li class="categories__item">
              <a class="categories__link" href="contact.php">
              <center>
              <img class="logo__img" src="images/contact.png" alt="Izzy logotype" width=" 40" height=" 40">
              <br>Contact us
                </center>
              </a>
            </li>

      -->
          </ul>
        </nav>
      </div>
    </div>
  </header>