<?php
// Include your database connection file here
session_start();

include("includes/db.php");
include("includes/header.php");
include("functions/functions3.php");
include("includes/main.php");
// Define your database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ecom_store";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>
  <!-- MAIN -->
  <main>
    <!-- HERO -->
    <div class="nero">
      <div class="nero__heading">
        <span class="nero__bold">shop</span> AT Izzy
      </div>
      <p class="nero__text">
      </p>
    </div>
  </main>


<div id="content" ><!-- content Starts -->
<div class="container" ><!-- container Starts -->

<div class="col-md-12" ><!--- col-md-12 Starts -->



</div><!--- col-md-12 Ends -->

<div class="col-md-3"><!-- col-md-3 Starts -->

<?php include("includes/sidebar.php"); ?>

</div><!-- col-md-3 Ends -->
<div class="sort-buttons">
        
    <a href="search.php?sort=latest" class="btn btn-default">Son Eklenen</a>
    <a href="search.php?sort=price_asc" class="btn btn-default">Fiyat: Düşükten Yükseğe</a>
    <a href="search.php?sort=price_desc" class="btn btn-default">Fiyat: Yüksekten Düşüğe</a>

  </div>
<div class="col-md-9">
            <!-- col-md-9 Starts -->
<?php 
// Define search query
$searchQuery = isset($_GET['search']) ? $_GET['search'] : "";

// Call getProducts function with search query
getProducts($searchQuery);
?>
</div>

<center><!-- center Starts -->

<ul class="pagination" ><!-- pagination Starts -->

<?php getPaginator(); ?>

</ul><!-- pagination Ends -->

</center><!-- center Ends -->



</div><!-- col-md-9 Ends --->



</div><!--- wait Ends -->

</div><!-- container Ends -->
</div><!-- content Ends -->



<?php

include("includes/footer.php");

?>

<script src="js/jquery.min.js"> </script>

<script src="js/bootstrap.min.js"></script>

<script>


$(document).ready(function(){

  // getProducts Function Code Starts

  function getProducts(){

  

// Products Categories Code Starts

var aInputs = Array();

var aInputs = $('li').find('.get_p_cat');

var aKeys = Array();

var aValues = Array();

iKey = 0;

$.each(aInputs,function(key,oInput){

if(oInput.checked){

aKeys[iKey] =  oInput.value

};

iKey++;

});

if(aKeys.length>0){

for(var i = 0; i < aKeys.length; i++){

sPath = sPath + 'p_cat[]=' + aKeys[i]+'&';

}

}

// Products Categories Code ENDS

   // Categories Code Starts

var aInputs = Array();

var aInputs = $('li').find('.get_cat');

var aKeys  = Array();

var aValues = Array();

var sPath = '';
iKey = 0;

    $.each(aInputs,function(key,oInput){

    if(oInput.checked){
      aKeys[iKey] =  oInput.value
      iKey++;
};

    
});

if(aKeys.length>0){

    for(var i = 0; i < aKeys.length; i++){
      sPath = sPath + 'cat[]=' + aKeys[i]+'&';
}

}

   // Categories Code ENDS

   // Loader Code Starts

$('#wait').html('<img src="images/load.gif">');

// Loader Code ENDS

// ajax Code Starts

$.ajax({

url:"load.php",

method:"POST",

data: sPath+'sAction=getProducts',

success:function(data){

 $('#Products').html('');

 $('#Products').html(data);

 $("#wait").empty();

}

});

    $.ajax({
url:"load.php",
method:"POST",
data: sPath+'sAction=getPaginator',
success:function(data){
$('.pagination').html('');
$('.pagination').html(data);
}

    });

// ajax Code Ends

   }

// getProducts Function Code Ends


$('.get_p_cat').click(function(){

getProducts();

});

$('.get_cat').click(function(){

getProducts();

});


 });

</script>

</body>

</html>
